<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type"
	content="text/html";
	charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
		<?php include 'style.css'; ?>
	</style>
</head>
<body>
<ul>
  <li><a href="index.php" class="active">Home</a></li>
  <li><a href="autoform.php">Auto formulier</a></li>
  <li><a href="klantform.php">Klanten formulier</a></li>
  <li><a href="autoschema.php">Auto Schema</a></li>
  <li><a href="klantschema.php">Klant Schema</a></li>
    <li><a href="verkochtschema.php">Verkocht Schema</a></li>
	<li><a href="alfabetisch.php">Alfabetisch Schema</a></li>
	<li><a href="namenschema.php">Namen Schema</a></li>
	<li><a href="getallenschema.php">Getallen Schema</a></li>
</ul>
<h1>home</h1>
</body>
</html>